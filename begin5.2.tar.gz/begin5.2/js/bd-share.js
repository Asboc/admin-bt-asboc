window._bd_share_config = {
	"common": {
		"bdSnsKey": {},
		"bdText": "",
		"bdMini": "2",
		"bdMiniList": false,
		"bdPic": "",
		"bdStyle": "1",
		"bdSize": "16"
	},
	"share": {
		"bdSize": 16
	}
};
with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~ ( - new Date() / 36e5)];
// with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'https://你的域名/static/api/js/share.js?v=89860593.js?cdnversion=' + ~ ( - new Date() / 36e5)];// 用于本地调用