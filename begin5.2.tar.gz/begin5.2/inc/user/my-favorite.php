<?php
/*
�ҵ��ղ�
*/

?>
<div class="favorite-content">
	<?php if ( zm_get_option('favorite_p')) { ?><?php wpzm_shortcode_func(); ?><?php } ?>
</div>